/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author wesly
 */
public class Listagem {
    private String todos;
    private String bovinos;
    private String suinos;
    private String aves;
    private String equinos;
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    

    public String getTodos() {
        return todos;
    }

    public void setTodos(String todos) {
        this.todos = todos;
    }

    public String getBovinos() {
        return bovinos;
    }

    public void setBovinos(String bovinos) {
        this.bovinos = bovinos;
    }

    public String getSuinos() {
        return suinos;
    }

    public void setSuinos(String suinos) {
        this.suinos = suinos;
    }

    public String getAves() {
        return aves;
    }

    public void setAves(String aves) {
        this.aves = aves;
    }

    public String getEquinos() {
        return equinos;
    }

    public void setEquinos(String equinos) {
        this.equinos = equinos;
    }
    
 
}
