/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author wesly
 */
public class Aves extends Animal{

    public Aves(String raca, String sexo) {
        super(raca, sexo);
    }
    
}
